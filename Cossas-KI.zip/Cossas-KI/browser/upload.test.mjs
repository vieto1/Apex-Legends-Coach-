import test from 'node:test';
import assert from 'node:assert/strict';
import { identify, uploadRemote, CHUNK_BYTES } from '../apexcoach/static/resumable-upload.js';

test('fingerprint includes the entire file, including middle chunks', async () => {
  const a = new File([new Uint8Array(CHUNK_BYTES + 5)], 'game.mp4');
  const bytes = new Uint8Array(CHUNK_BYTES + 5);
  bytes[CHUNK_BYTES / 2] = 1;
  const b = new File([bytes], 'game.mp4');
  assert.notEqual((await identify(a)).fingerprint, (await identify(b)).fingerprint);
});

test('remote upload resolves a lost acknowledgement using server offset', async () => {
  const file = new File([new Uint8Array(1024 ** 2 + 101)], 'game.mp4');
  let offset = 0, loseAck = true, completed = 0, patches = 0;
  const progress = [];
  const request = async (path, options = {}) => {
    if (path === '/api/uploads') {
      assert.equal(JSON.parse(options.body).size, file.size);
      return { id:'session', offset, chunk_bytes:CHUNK_BYTES };
    }
    if (path.endsWith('/complete')) { completed++; return { id:'match' }; }
    if (options.method === 'PATCH') {
      patches++;
      assert.equal(Number(options.headers['Upload-Offset']), offset);
      const hash = Buffer.from(await crypto.subtle.digest('SHA-256', await options.body.arrayBuffer())).toString('hex');
      assert.equal(options.headers['Upload-Checksum'], hash);
      offset += options.body.size;
      if (loseAck) { loseAck = false; throw new TypeError('Synthetic network failure'); }
    }
    return { id:'session', offset, chunk_bytes:CHUNK_BYTES };
  };
  assert.deepEqual(await uploadRemote(file, {}, request, (value) => progress.push(value)), { id:'match' });
  assert.equal(offset, file.size);
  assert.equal(patches, 2); // the already-committed megabyte was not resent
  assert.equal(completed, 1);
  assert.equal(progress.at(-1), 1);
});
