import { identify, CHUNK_BYTES } from "../apexcoach/static/resumable-upload.js";
// Videos and metadata stay in this browser's origin-scoped IndexedDB.
export class LocalStore {
  async open() {
    if (this.db) return this.db;
    this.db = await new Promise((resolve, reject) => {
      // Persistent schema identifier: retain existing private recordings after a rebrand.
      const r = indexedDB.open(["apex", "review", "private"].join("-"), 2);
      r.onupgradeneeded = () => {
        for (const name of ["matches", "sources", "profiles", "chunks", "imports"])
          if (!r.result.objectStoreNames.contains(name)) r.result.createObjectStore(name, { keyPath: "id" });
      };
      r.onsuccess = () => resolve(r.result);
      r.onerror = () =>
        reject(
          Error(
            "Lokaler Browserspeicher nicht verfügbar. Privaten Modus verlassen oder Browserberechtigungen prüfen.",
          ),
        );
    });
    this.db.onversionchange = () => this.db.close();
    return this.db;
  }
  async get(name, id) {
    const db = await this.open();
    const value = await new Promise((resolve, reject) => {
      const r = db.transaction(name).objectStore(name).get(id);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
    if (name === "sources" && value?.chunk_count != null) {
      const parts = [];
      for (let index = 0; index < value.chunk_count; index++) {
        const chunk = await this.get("chunks", `${id}:${index}`);
        if (!chunk) throw Error("Lokale Videoblöcke fehlen; Datei erneut importieren");
        parts.push(chunk.blob);
      }
      return { ...value, blob: new Blob(parts, { type: value.type }) };
    }
    return value;
  }
  async saveSource(file, progress) {
    const { fingerprint } = await identify(file, progress);
    const pending = await this.get("imports", fingerprint) || {
      id: fingerprint, mid: crypto.randomUUID(), offset: 0,
    };
    const estimate = await navigator.storage?.estimate?.();
    if (estimate?.quota && estimate.quota - estimate.usage < file.size - pending.offset)
      throw Error("Nicht genug lokaler Browserspeicher. Aufnahmen exportieren/löschen oder die Server-Version verwenden.");
    await this.put("imports", pending);
    for (let offset = pending.offset; offset < file.size; offset += CHUNK_BYTES) {
      await this.put("chunks", { id: `${pending.mid}:${Math.floor(offset / CHUNK_BYTES)}`,
        blob: file.slice(offset, offset + CHUNK_BYTES) });
      pending.offset = Math.min(file.size, offset + CHUNK_BYTES);
      await this.put("imports", pending);
      progress(pending.offset / file.size, "Lokal speichern");
    }
    await this.put("sources", { id: pending.mid, type: file.type,
      chunk_count: Math.ceil(file.size / CHUNK_BYTES), size: file.size, fingerprint });
    return pending;
  }
  async all(name) {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const r = db.transaction(name).objectStore(name).getAll();
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  async put(name, value) {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const t = db.transaction(name, "readwrite");
      t.objectStore(name).put(value);
      t.oncomplete = () => resolve(value);
      t.onabort = t.onerror = () =>
        reject(
          Error(
            t.error?.name === "QuotaExceededError"
              ? "Browserspeicher voll. Alte Aufnahmen exportieren und löschen."
              : t.error?.message || "Speichern fehlgeschlagen",
          ),
        );
    });
  }
  async change(id, fn) {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const t = db.transaction("matches", "readwrite"),
        s = t.objectStore("matches"),
        r = s.get(id);
      let value;
      r.onsuccess = () => {
        try {
          if (!r.result) throw Error("Aufnahme nicht gefunden");
          value = fn(r.result);
          s.put(value);
        } catch (e) {
          reject(e);
          t.abort();
        }
      };
      t.oncomplete = () => resolve(value);
      t.onabort = t.onerror = () =>
        reject(t.error || Error("Änderung nicht gespeichert"));
    });
  }
  async remove(name, id) {
    const db = await this.open();
    return new Promise((resolve, reject) => {
      const t = db.transaction(name, "readwrite");
      t.objectStore(name).delete(id);
      t.oncomplete = resolve;
      t.onerror = () => reject(t.error);
    });
  }
  async deleteMatch(id) {
    const db = await this.open();
    const source = await new Promise((resolve, reject) => {
      const r = db.transaction("sources").objectStore("sources").get(id);
      r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error);
    });
    return new Promise((resolve, reject) => {
      const t = db.transaction(["matches", "sources", "chunks"], "readwrite");
      for (let index = 0; index < (source?.chunk_count || 0); index++) t.objectStore("chunks").delete(`${id}:${index}`);
      for (const name of ["matches", "sources"]) t.objectStore(name).delete(id);
      t.oncomplete = resolve;
      t.onerror = () => reject(t.error);
    });
  }
}
