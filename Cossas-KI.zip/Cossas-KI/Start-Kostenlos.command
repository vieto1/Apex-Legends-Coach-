#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
if [[ ! -x .venv/bin/python ]]; then
  echo 'Zuerst Einrichten-Kostenlos.command ausführen.'
  read -r -p 'Zum Schließen Enter drücken. ' _
  exit 1
fi
.venv/bin/python scripts/free_setup.py "$@"
result=$?
if [[ "$result" != 0 ]]; then read -r -p 'Zum Schließen Enter drücken. ' _; fi
exit "$result"
