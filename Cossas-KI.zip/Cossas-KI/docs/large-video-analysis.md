# Große Videos und optionale Cloud-Vision

**Aktuelle Empfehlung ohne API-Kosten:** [kostenlose lokale KI](free-local.md).
Cloud-Vision ist jetzt ausdrücklich opt-in; ein vorhandener Schlüssel allein
aktiviert keine Modellaufrufe.

## Was behoben wurde

Das alte 2-GiB-Verbot lag gleichzeitig in `static/app.js`, `browser/client.mjs`,
der ASGI-Middleware und dem Multipart-Handler. Es war kein GitHub-Pages-Uploadlimit:
die reine Pages-Version speichert Videos im Browser. Große Multipart-Anfragen
würden außerdem zunächst von Starlette auf temporären Speicher geschrieben.

Der reguläre Server-Import verwendet jetzt `/api/uploads`: kleine rohe Blöcke,
SHA-256 je Block, dauerhafter SQLite-Offset, `fsync`, Wiederaufnahme nach Seiten-
und Serverneustart und idempotenter Abschluss. Die Oberfläche beginnt mit 1 MiB
pro Anfrage und verkleinert nach Verbindungsfehlern bis auf 64 KiB; der Server
akzeptiert maximal 8 MiB. Der Import berechnet vorher eine vollständige
blockbasierte Dateikennung, damit eine veränderte Datei nicht an eine alte
Aufnahme angehängt wird. Dieselbe Datei erneut auswählen und **Aufnahme analysieren**
starten setzt einen unterbrochenen Import fort. Upload und Dateiprüfung zeigen
einen eigenen Fortschritt. Der Server hält maximal einen Block, nicht das Video,
im RAM. Eine Warteschlange von vier Analysen bleibt bestehen; ein volles
Analysekontingent verwirft keine hochgeladenen Blöcke.

Auch IndexedDB speichert neue Browser-Importe blockweise und setzt unterbrochene
Importe bei erneuter Dateiauswahl fort. Die Datenbankmigration erhält alte Videos,
Profile und Notizen. Verfügbarer Browser-/Festplattenspeicher bleibt eine reale
Grenze. Fehlermeldungen nennen Speicherprobleme; es gibt keinen künstlichen
2-GiB-Dateigrenzwert mehr. Unvollständige Server-Uploads können über
`DELETE /api/uploads/<id>` gelöscht werden; sie werden nicht automatisch entfernt.

Der alte Multipart-Endpunkt bleibt für kleine Integrationen und Demos erhalten:
64 MiB Dateigröße, ca. 66 MiB Requestlimit. Große Dateien müssen den Blockendpunkt
verwenden. Die separate Bildschirmaufnahme besitzt weiterhin eine Schutzgrenze
von ca. 1,9 GiB, weil `MediaRecorder`-Teile im Speicher gesammelt werden. Das
beschränkt **nicht** den Import von OBS-/Gameplay-Dateien. Eine unbegrenzt lange
Live-Aufnahme wurde nicht implementiert.

## Tatsächliche Analyse und Grenzen

Vorher wurden mit OpenCV bzw. Browser-Seeks nur Einzelbilder im Sekundentakt
betrachtet. Es gab kein multimodales Modell. FFmpeg enthielt außerdem ein
stilles `-t 7200` und ein festes Konvertierungszeitlimit von 30 Minuten.

Der Python-Pfad dekodiert nun alle Videoframes sequenziell. FFmpeg erhält variable
Bildraten; die Auswertung verwendet gemessene Präsentationszeitstempel statt
`Frameindex / Durchschnitts-FPS`. Eine widersprüchliche Frameanzahl, ein
Dekodierfehler oder fehlende Modellfenster führen zu einem Fehlerstatus, nicht
zu einem angeblich vollständigen Bericht. Die vorhandenen Grenzen von zwei
Stunden und 3840×2160 werden vor Verarbeitung ausdrücklich geprüft. FFmpeg
schneidet nicht mehr still ab; das Konvertierungsbudget beträgt vier Stunden.

Jeder Frame wird auf visuelle Wechsel und kalibrierte Ressourcenänderungen
geprüft. Die teurere HUD-Ziffern-OCR bleibt bei 1 Hz. Aus diesen Beobachtungen
entstehen Sequenz-/Kampfhinweise. Cloud-Vision bekommt anschließend **echte
JPEG-Videobilder** in chronologischen 20-Sekunden-Fenstern mit vier Sekunden
Überlappung, standardmäßig zwei Bilder pro Sekunde. Auch Zeitabschnitte ohne
lokal erkannten Fight werden dem Modell übergeben. Das Modell kann zusätzliche
Kampfsequenzen erkennen und liefert Geschehen, Fehler/Chance, bessere Entscheidung
und zitierte Framezeiten. Fensterzeiten werden relativ zum Clip validiert und
anschließend auf die Gesamtvideozeit zurückgerechnet. Die Timeline und der
Markdown-Bericht zeigen Minute:Sekunde. Überlappung liefert Kontext; jeder
Ereignisstart gehört einem einzigen Fenster.

Das ist **keine Behauptung**, dass jedes Frame semantisch vom Cloud-Modell gesehen
wird oder dass jeder Fight sicher erkannt wird. Zwischen Modellbildern können
kurze Details fehlen; Audio und Squad-Comms werden nicht analysiert. Konfidenzen
sind Modellschätzungen, keine kalibrierten Wahrscheinlichkeiten. Eine Überlegenheit
gegenüber OmniAI ist ohne annotierte echte Gameplay-Videos und Vergleichstest
nicht belegt. Die reine Offline-Pages-Version nutzt weiterhin lokale 1-Hz-HUD-
Heuristiken; die vollständige Dekodierung und Cloud-Pipeline laufen im Backend.

`coverage.json` dokumentiert Dekodierung, Bildanzahl, Zielbildrate und vollständig
ausgewertete Modellfenster. `scan.json` hält die lokale Sequenzzeitleiste und
Beobachtungen. Modellresultate liegen unter `vision-results/` und werden erst nach
erfolgreicher Validierung atomar gespeichert. Erneutes Analysieren verwendet
passende Checkpoints wieder (Datei, Profil, Modell, Endpoint, Promptversion).
Bei Token-/Kontextüberschreitung werden Fenster rekursiv mit Überlappung geteilt;
auch diese Teilfenster werden gespeichert. Bei Netzwerkfehlern gibt es begrenzte
Wiederholungen. Ein abgebrochener Lauf bleibt fehlgeschlagen, bis die fehlenden
Fenster erfolgreich nachgeholt wurden. Eigene Notizen und Markierungen bleiben.

## Cloud-Modell aktivieren

Im Backend sicher setzen, niemals in Git oder Frontend-JavaScript:

| Variable | Standard / Wirkung |
| --- | --- |
| `APEX_VISION_MODE` | `off`; für diese optionale Cloud-Konfiguration ausdrücklich `cloud` setzen |
| `APEX_VISION_API_KEY` | API-Schlüssel, erforderlich für Cloud-Coaching |
| `APEX_VISION_API_URL` | `https://api.openai.com/v1/chat/completions` |
| `APEX_VISION_MODEL` | `gpt-4.1-mini`, muss Bilder und JSON-Antworten unterstützen |
| `APEX_VISION_FPS` | `2`, erlaubt 0,5–4 Bilder/s |
| `APEX_VISION_MAX_WINDOWS` | `200`, logisches Fensterbudget je Video |
| `APEX_VISION_MAX_REQUESTS` | `300`, tatsächliche API-Aufrufe je Lauf inklusive Wiederholungen/Teilfenster |

Bei fehlendem Schlüssel meldet die Oberfläche ausdrücklich lokale HUD-Auswertung
und **kein** Cloud-Coaching. Im Cloud-Umgebungsentwurf wurden die Schlüsselanforderung,
Modell-/Endpointvorschläge und das Ziel `api.openai.com` gespeichert. Dort den
Schlüssel sicher hinterlegen, Änderungen speichern und die Umgebung veröffentlichen.
Für einen anderen Anbieter Zielhost und Schlüsselbindung entsprechend konfigurieren.
TLS-Prüfung bleibt aktiv. Fehler enthalten keine API-Schlüssel oder Providerantworten.

25 Minuten benötigen regulär 94 Fenster; mit zwei Bildern/s sind es ca. 3.750
übergebene Bilder inklusive Überlappung. Providerpreise und tatsächliche Bildtokens
variieren. Das Request-/Fensterbudget verhindert unbegrenzte Aufrufe, ist aber
kein Euro-Limit. Für einen harten Geldbetrag ein vom Anbieter tatsächlich
erzwungenes Ausgabenlimit oder einen vorgeschalteten Abrechnungsproxy verwenden.
Projektbudgets können lediglich Warnschwellen sein (insbesondere bei OpenAI);
sie sind nicht automatisch eine Ausgabensperre. Passende Rate-Limits ergänzen. Der Code überspringt bei Budgetüberschreitung
keine Sequenzen, sondern meldet einen fortsetzbaren Fehler.

Native Einrichtung bleibt:

```bash
python -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
./scripts/start.sh
```

Der Prozess benötigt FFmpeg/ffprobe, Tesseract und ausreichend freien Speicher
für Original, normalisiertes Video, Frames und Clips. Nur ein Uvicorn-Worker;
SQLite, Warteschlange und Locks entsprechen dem bisherigen privaten Betriebsmodell.
Docker Compose übernimmt diese Variablen aus der aufrufenden Umgebung. Schlüssel
über die Deployment-Secret-Verwaltung bereitstellen; keine ausgefüllten Secrets
einchecken oder in Diagnoseausgaben (`docker compose config`) drucken.

## GitHub Pages und externe Hosting-Einstellungen

GitHub Pages kann keinen FastAPI-Prozess und keinen geheimen API-Schlüssel betreiben.
Für den Browser auf demselben Rechner reicht die lokale Python-Oberfläche. Für
entfernten Zugriff ist ein gesondert betriebenes HTTPS-Backend erforderlich.

1. Backend mit persistentem Datenvolume und obigen Variablen betreiben. Die
   Anwendung besitzt weiterhin keine eigenen Nutzerkonten. Beim entfernten Betrieb
   **alle** API-, Medien- und Uploadpfade hinter dem bestehenden Zugangsschutz/
   authentifizierten Reverse-Proxy betreiben. Nicht ungeschützt öffentlich schalten.
2. Backend: `APEX_ALLOWED_ORIGINS=https://vieto1.github.io` (nur Origin, kein Projektpfad).
   Zusätzliche Origins kommasepariert; keine Wildcards. Credentials werden unterstützt.
   CORS ist kein Zugangsschutz. Bei Cookie-Authentifizierung müssen Browser und
   Auth-Proxy Cookies zulassen; ein gemeinsamer eigener Site-Host vermeidet
   Drittanbieter-Cookiebeschränkungen.
3. GitHub Repository → Settings → Secrets and variables → Actions → **Variables**:
   `APEX_API_BASE_URL=https://DEIN-BACKEND-HOST` setzen. Nur HTTPS-Origin ohne
   Pfad/Schlüssel. Der vorhandene Pages-Workflow übernimmt diese Variable beim Build.
   Ohne sie bleibt die Website offline/browserlokal. API-Schlüssel gehören nicht
   in diese Variable. Ein neuer Pages-Build ist für die Verbindung erforderlich.
4. Reverse-Proxy/CDN muss `GET`, `POST`, `PATCH`, `DELETE`, `PUT` und CORS-`OPTIONS`
   sowie `Upload-Offset`, `Upload-Checksum`, `Content-Type` weitergeben.
   Das Requestlimit für `/api/uploads` muss mindestens 8 MiB erlauben (empfohlen
   10 MiB); es muss **nicht** auf die gesamte Videogröße erhöht werden.
5. Beispiel für eine vorhandene Nginx-Location `/api/uploads`:

   ```nginx
   client_max_body_size 10m;
   client_body_timeout 300s;
   proxy_request_buffering off;
   proxy_read_timeout 300s;
   proxy_send_timeout 300s;
   ```

   Für den Legacy-Multipart-Pfad bei Bedarf 66 MiB erlauben. Request-Timeouts
   gelten je Block/Abschluss, nicht für den ganzen Analysejob. CDN-Hardlimits
   sind anbieterspezifisch: erlaubte Requestgröße mindestens die verwendete
   Blockgröße, keine Blockierung von `PATCH` und kein Cache für mutierende APIs.
   Die Analyse läuft nach dem kurzen HTTP-202-Abschluss im Hintergrund.

Am Proxy außerdem den ursprünglichen Host und das HTTPS-Schema weitergeben;
Uvicorn nur die konkrete Proxy-Adresse für Forwarded-Header vertrauen lassen.

Ein bestimmter CDN-/Storageanbieter ist im Repository nicht konfiguriert; es gibt
daher keine nachgewiesene externe 2-GB-Sperre und keine vorhandene S3-Konfiguration.
Externe Deployment-Einstellungen und die API-Zugangsdaten lassen sich nicht durch
eine reine Quellcodeänderung aktivieren.

## Wiederholbare Prüfungen

```bash
.venv/bin/python -m pytest -q
npm test
npm run build
# Opt-in: überträgt und schreibt tatsächlich mehr als 2 GiB, braucht freien Speicher.
APEX_RUN_LARGE_UPLOAD_TEST=1 .venv/bin/python -m pytest -q \
  tests/test_uploads.py::test_actual_upload_over_two_gib_and_full_decode
```

Der zusätzliche Browser-Großdateitest ist aufrufbar mit:

```bash
APEX_LARGE_VIDEO=/pfad/zum/video-ueber-2-gib.mp4 \
  node scripts/large-browser-import-smoke.cjs
```

Dafür die gebaute Browserfassung auf Port 8787 bereitstellen; `APEX_PAGES_URL`
kann überschrieben werden. Der Test verwendet ein frisches Browserprofil.

Der große Test nutzt eine gültige MP4 mit einem großen legalen `free`-Atom
(Padding). Jedes Byte wird übertragen und per SHA-256 verglichen; die kurze
Videospur wird anschließend vollständig dekodiert. Das belegt den Dateigrößenpfad,
keine Gameplay-Qualität. Ein separater Test erzeugt **25 Minuten** Video, prüft
alle 3.000 Frames bei 2 fps, jedes Zeitfenster, absolute Zeitstempel und die
Wiederaufnahme nach einem simulierten Modellfehler. Modellantworten in Tests
sind ausdrücklich synthetisch; ein echter Cloud-Qualitätstest benötigt Schlüssel
und repräsentatives Gameplay.

Praktischer Abnahmetest mit eigenem >2-GiB-Gameplay: Upload bei z. B. 30 % trennen,
Seite/Server neu starten, identische Datei erneut wählen, auf Fortsetzung statt
Neustart achten. Nach Abschluss Original herunterladen und SHA-256 vergleichen.
Im JSON-Bericht müssen `coverage.decode_complete=true`, gleiche Frameanzahlen,
Endzeit gleich Videodauer und bei aktiver Cloud
`model_windows_completed == model_windows_total` sowie `model_status=complete`
stehen. Erste, mittlere und letzte Kampfsequenz im Player gegenprüfen. Für echte
Qualitätsabnahme sämtliche Fights manuell annotieren und Recall, Fehlalarme,
Zeitstempelfehler und Nützlichkeit der Empfehlungen messen.

## Geänderte Dateien

- Upload und Server: `apexcoach/uploads.py`, `apexcoach/limits.py`, `apexcoach/app.py`.
- Analyse und Bericht: `apexcoach/pipeline.py`, `apexcoach/coaching.py`, `apexcoach/store.py`, `apexcoach/review.py`.
- Gemeinsame Oberfläche: `apexcoach/static/app.js`, `apexcoach/static/index.html`, `apexcoach/static/resumable-upload.js`.
- Browser-Speicherung: `browser/client.mjs`, `browser/store.mjs`.
- Laufzeit und Build: `requirements.txt`, `requirements-dev.txt`, `compose.yaml`, `scripts/build-pages.mjs`, `.github/workflows/pages.yml`.
- Tests: `tests/test_uploads.py`, `tests/test_coaching.py`, `browser/upload.test.mjs`, `scripts/browser-smoke.cjs`, `scripts/large-browser-import-smoke.cjs`, `scripts/local-import-resume-smoke.cjs`, `scripts/pages-backend-smoke.cjs`.
- Dokumentation: `README.md`, `docs/architecture.md`, `docs/github-pages.md`, `docs/large-video-analysis.md`.

Geprüft in dieser Cloud-Sitzung: 42 Python-Tests bestanden; der bewusst aus der
Standardsuite ausgelassene Großdateitest wurde separat ausgeführt und bestand.
9 JavaScript-Tests und Build bestanden. Browserprüfungen für Aufnahme/Upload,
Pages-Demo, Desktop/Mobilansicht, bestehende Datenmigration, lokale Import-
Wiederaufnahme, lokalen >2-GiB-Import und separate Backend-Anbindung bestanden.
Ein echter Cloud-Modelllauf war ohne API-Schlüssel nicht möglich; die
Modellverträge, Bildübergabe, Fenster, Limits und Wiederaufnahme wurden mit
synthetischen Antworten geprüft.
