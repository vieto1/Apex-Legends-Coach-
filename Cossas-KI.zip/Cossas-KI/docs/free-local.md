# Kostenlose KI auf deinem Mac oder Windows-PC

Jeder installiert die Anwendung und sein Modell auf dem eigenen Rechner. Deine
Freunde benötigen weder Zugriff auf dein MacBook noch einen gemeinsamen Server.
Es fallen keine API- oder Hostinggebühren an; Hardware, freier Speicher und Strom
bleiben erforderlich. Nach dem ersten Download ist lokale Analyse offline möglich.

## Mac, einschließlich Apple Silicon / M5

1. Das vollständige aktuelle Startpaket entpacken. Bei einem Git-Checkout die
   Dateien im vorhandenen Projektordner verwenden.
2. Einmal [Homebrew](https://brew.sh) installieren, falls noch nicht vorhanden.
3. `Einrichten-Kostenlos.command` öffnen. Es installiert Python 3.12, FFmpeg,
   Tesseract, Ollama, die Projektabhängigkeiten und ein lokales Vision-Modell.
4. Anschließend für jede Sitzung `Start-Kostenlos.command` öffnen. Die Oberfläche
   öffnet sich nach dem Serverstart im Browser. Das Terminalfenster geöffnet lassen.
5. Video auswählen. Die Oberfläche muss **LOKALE KI · KEINE API-GEBÜHREN** anzeigen.

Das Modell läuft nativ unter macOS, damit Ollama die Apple-GPU über Metal nutzen
kann. Die KI wird auf dem Mac nicht in einen Linux-Docker-Container verlagert.
Bei einer macOS-Sicherheitsabfrage die Quelle prüfen und die Datei gezielt über
die vom Betriebssystem angebotene Öffnen-Funktion freigeben; keine globalen
Sicherheitseinstellungen abschalten. Fehlende Ausführungsrechte können im
Projektordner mit `chmod +x *-Kostenlos.command` gesetzt werden.

## Windows 10/11

1. Windows App Installer (`winget`) muss verfügbar sein; ggf. aus dem Microsoft
   Store installieren. Aktuelle GPU-Treiber vom Geräte-/GPU-Hersteller verwenden.
2. Vollständiges Startpaket entpacken, dann `Einrichten-Kostenlos.cmd` starten.
   Die Einrichtung verwendet offizielle winget-Pakete für Python 3.12, FFmpeg,
   Tesseract und Ollama und lädt anschließend das lokale Modell.
3. Danach `Start-Kostenlos.cmd` verwenden. Auch hier muss der Browser **LOKALE KI**
   melden. Jeder Freund arbeitet mit seiner eigenen Installation und seinen Daten.

Windows kann für Programminstallationen eine UAC-Bestätigung verlangen. Die
PowerShell-Einrichtung verwendet `RemoteSigned`, keine abgeschaltete
Paketprüfsumme oder globale Execution-Policy. Wenn ein vertrauenswürdig bezogenes
ZIP wegen seiner Download-Markierung blockiert wird, Herkunft/Prüfsumme prüfen
und das ZIP in den Dateieigenschaften gezielt entsperren, dann erneut entpacken.
Bei Unternehmensrichtlinien den Administrator einbeziehen.

Wenn nach einer Installation ein Programm nicht gefunden wird: Terminal schließen
und Einrichtung erneut starten. Die Installation ist wiederholbar. Die vorhandene
`Start-Cossas-KI.cmd` ist weiterhin die bisherige Docker-Variante; für native lokale
KI die neue `Start-Kostenlos.cmd` benutzen.

## Startprofile und Leistung

Die Einrichtung erkennt RAM, Apple-Silicon-Plattform und, wenn verfügbar, den
Grafikspeicher über `nvidia-smi`. Das sind konservative Startprofile, keine
Benchmarks und keine Garantie, dass das größte Modell am schnellsten ist:

| Hardware | Automatischer Startpunkt |
| --- | --- |
| Apple Silicon mit 8 GB RAM | Qwen3-VL 2B, kleinere Bilder, 0,5 Bilder/s |
| Apple Silicon mit 16 GB RAM | Qwen3-VL 4B, 1 Bild/s |
| Apple Silicon mit 24–32 GB RAM | Qwen3-VL 8B, 1 Bild/s |
| Apple Silicon ab ca. 48 GB RAM | Qwen3-VL 32B, qualitätsorientierter Startpunkt |
| NVIDIA mit ca. 8 GB VRAM | Qwen3-VL 4B |
| NVIDIA mit mindestens 12 GB VRAM | Qwen3-VL 8B (ab 40 GB VRAM: 32B) |
| CPU-only oder GPU-Erkennung fehlt | Qwen3-VL 2B; erheblich langsamere Analyse möglich |

Die Entscheidung berücksichtigt beim Mac sechs GiB Reserve fürs System. Offene
Programme und ein großer Bildkontext benötigen zusätzlichen Speicher. Modelle
werden in Ollamas angebotener komprimierter Variante geladen. Die tatsächliche
GPU-Unterstützung hängt von Ollama-Version und Treibern ab; `ollama ps` zeigt den
laufenden Prozessor/Offload an. AMD-/Intel-GPUs werden durch diese Startprofilauswahl
nicht zuverlässig klassifiziert: Ollama kann sie abhängig vom Treiber unterstützen,
die automatische Auswahl bleibt dann vorsichtig. M5 allein legt die Modellgröße
nicht fest; die RAM-Ausstattung ist entscheidend.

Die Profile verwenden acht Sekunden pro Modellfenster mit zwei Sekunden
Überlappung, 512/768 Pixel Bildbreite und 8K/16K Kontext. Die vollständige lokale
Videodekodierung bleibt erhalten. Größere Modelle oder mehr Bilder/s sind nicht
automatisch genauer für Apex. Für einen Vergleich dieselben manuell annotierten
Fights verwenden und Laufzeit, übersehene Fights, Fehlalarme und Nützlichkeit messen.

Modellwechsel nach eigener Messung (lädt die gewählte Variante):

```bash
# macOS / Linux, im Projektordner
.venv/bin/python scripts/free_setup.py --setup --model qwen3-vl:8b
```

```powershell
# Windows, im Projektordner
.venv\Scripts\python.exe scripts\free_setup.py --setup --model qwen3-vl:8b
```

`data/free-settings.json` enthält die lokalen Startwerte. Ein erneutes Einrichten
aktualisiert sie. Ein zu großes Modell kann zu Speichermangel führen; dann wieder
eine kleinere Variante wählen. Keine Echtzeitgeschwindigkeit und keine OmniAI-
Überlegenheit zugesagt: Dafür fehlen echte Hardware-/Gameplay-Benchmarks.

## Daten, Kosten und bestehende Installationen

- Native Aufnahmen liegen im bisherigen nativen `data/`-Verzeichnis; Modelle im
  Ollama-Modellspeicher. Weder Modelle noch private Aufnahmen sind im Start-ZIP.
- Die alten Docker-Volumes bleiben unberührt. Daten aus Docker werden nicht
  automatisch in die native Installation verschoben oder gelöscht.
- Der kostenlose Starter überschreibt Cloud-URLs im gestarteten Prozess mit
  `127.0.0.1:11434`, entfernt den API-Schlüssel und prüft, dass ein lokales
  Vision-Modell installiert ist. Es gibt keinen automatischen Cloud-Fallback.
- Der generelle Standard ist `APEX_VISION_MODE=off` (nur HUD). `local` aktiviert
  die lokale Modellanbindung ohne Schlüssel; `cloud` ist nur explizit wählbar.
  Ein alter Cloud-Schlüssel allein aktiviert nichts mehr.
- Beim Start eines eigenen Ollama-Prozesses setzt der Helfer `OLLAMA_NO_CLOUD=1`.
  Ein schon laufender Ollama-Prozess wird nicht umkonfiguriert; die Einrichtung
  verwendet ausschließlich lokale `qwen3-vl`-Gewichte und prüft das lokale Alias.
- Zum Beenden der Anwendung im Startfenster Strg+C drücken. Ollama kann als
  Hintergrunddienst weiterlaufen. `ollama stop cossas-ki-free` gibt Modell-RAM frei;
  Ollama selbst beenden, wenn kein lokaler Modelldienst mehr gebraucht wird.
- Nur Loopback-Bindung: Die Anwendung wird nicht ungeschützt im Internet oder im
  WLAN veröffentlicht. Freunde installieren ihre eigene Kopie; Berichte und Clips
  können exportiert und miteinander geteilt werden.

GitHub Pages bleibt als kostenlose Oberfläche mit lokalen HUD-Heuristiken nutzbar.
Das hier beschriebene volle lokale Modell läuft über die native Oberfläche auf
dem eigenen Rechner. Handys/Tablets und Browser ohne Installation erhalten damit
nicht dieselbe lokale Modellleistung wie ein Mac/PC.

## Verifikation und Grenzen der Prüfung

Die Modellverträge, Bildübergabe ohne Schlüssel, lokale Endpointbeschränkung,
Hardwareprofile und das Erzeugen der Startkonfiguration werden automatisiert
geprüft. Die vorhandenen Video-, Upload- und Browserprüfungen bleiben bestehen.
Diese Linux-Cloud-Sitzung besitzt kein installiertes Ollama und keine Mac-/Windows-
GPU. Ein echter Modelllauf und die native Ausführung der Homebrew-/winget-
Installation wurden hier nicht durchgeführt. Diese Schritte müssen auf den
Zielgeräten geprüft werden; synthetische Modellantworten belegen keine KI-Qualität.

Ein echter Abnahmetest nach Einrichtung: `ollama ps` während der Analyse prüfen,
zuerst einen kurzen Gameplay-Clip testen, dann ein 25-Minuten-Video. Im Bericht
müssen `coverage.model_mode=local`, `model_status=complete` und vollständig
abgeschlossene Fenster stehen. Fights am Anfang, in der Mitte und am Ende gegen
das Original prüfen. Offline-Test nach dem ersten Download: Internet trennen und
denselben Clip erneut analysieren; lokale Verarbeitung muss weiter funktionieren.

Offizielle Quellen: [Ollama](https://github.com/ollama/ollama),
[Qwen3-VL](https://github.com/QwenLM/Qwen3-VL),
[Ollama-Umgebungsoptionen](https://github.com/ollama/ollama/blob/main/envconfig/config.go).
