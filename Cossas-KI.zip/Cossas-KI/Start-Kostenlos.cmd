@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Zuerst Einrichten-Kostenlos.cmd ausfuehren.
 pause
 exit /b 1
)
.venv\Scripts\python.exe scripts\free_setup.py %*
if errorlevel 1 (
 pause
 exit /b 1
)
