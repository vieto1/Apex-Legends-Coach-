#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
bash scripts/setup-free.sh "$@"
result=$?
read -r -p 'Zum Schließen Enter drücken. ' _
exit "$result"
