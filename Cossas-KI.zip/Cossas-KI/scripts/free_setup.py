"""Native local-model setup shared by macOS, Windows and Linux launchers.

Does not install OS packages or send video to cloud providers. Ollama verifies
downloaded model layers. Settings contain no secrets and stay in ignored data/.
"""
import argparse
import ctypes
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
import httpx

ROOT = Path(__file__).resolve().parents[1]
SETTINGS = ROOT/'data'/'free-settings.json'
OLLAMA = 'http://127.0.0.1:11434'
MODELS = {'qwen3-vl:2b', 'qwen3-vl:4b', 'qwen3-vl:8b', 'qwen3-vl:32b'}
ALIAS = 'cossas-ki-free'


def output(args):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=10, check=True).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ''


def hardware():
    system = platform.system()
    ram = 0
    if system == 'Darwin':
        raw = output(['sysctl', '-n', 'hw.memsize'])
        ram = int(raw) / 1024**3 if raw.isdigit() else 0
    elif system == 'Windows':
        class Memory(ctypes.Structure):
            _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong),
                        ('total', ctypes.c_ulonglong), ('available', ctypes.c_ulonglong),
                        ('page_total', ctypes.c_ulonglong), ('page_available', ctypes.c_ulonglong),
                        ('virtual_total', ctypes.c_ulonglong), ('virtual_available', ctypes.c_ulonglong),
                        ('extended', ctypes.c_ulonglong)]
        value = Memory()
        value.length = ctypes.sizeof(value)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value)):
            ram = value.total / 1024**3
    else:
        try:
            ram = os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES') / 1024**3
        except (ValueError, OSError, AttributeError):
            pass
    vram = output(['nvidia-smi', '--query-gpu=memory.total', '--format=csv,noheader,nounits'])
    gpu = max((float(x)/1024 for x in vram.splitlines() if x.strip().replace('.', '', 1).isdigit()), default=0)
    apple = system == 'Darwin' and (platform.machine() == 'arm64' or 'Apple' in output(['sysctl','-n','machdep.cpu.brand_string']))
    return {'system':system, 'ram_gib':round(ram,1), 'gpu_vram_gib':round(gpu,1), 'apple_silicon':apple}


def profile(info):
    """Conservative starting points, not a claim of measured game-model quality."""
    available = info['ram_gib']-6 if info['apple_silicon'] else info['gpu_vram_gib']
    if available >= 40:
        model = 'qwen3-vl:32b'
    elif available >= 12:
        model = 'qwen3-vl:8b'
    elif available >= 7:
        model = 'qwen3-vl:4b'
    else:
        model = 'qwen3-vl:2b'
    if not info['apple_silicon'] and not info['gpu_vram_gib']:
        # RAM is not evidence of GPU acceleration. CPU-only inference stays small.
        model = 'qwen3-vl:2b'
    return {'base_model':model, 'model':ALIAS, 'fps':1 if available >= 7 else .5,
            'window_seconds':8, 'overlap_seconds':2, 'image_width':768 if available >= 7 else 512,
            'context_length':16384 if available >= 7 else 8192, 'timeout':1200, 'hardware':info}


def ollama_binary():
    found = shutil.which('ollama')
    candidates = [Path('/Applications/Ollama.app/Contents/Resources/ollama'),
                  Path('/opt/homebrew/bin/ollama'),
                  Path(os.getenv('LOCALAPPDATA', ''))/'Programs'/'Ollama'/'ollama.exe']
    return found or next((str(p) for p in candidates if p.is_file()), None)


def reachable():
    try:
        with httpx.Client(trust_env=False, timeout=2) as client:
            return client.get(OLLAMA+'/api/version').status_code == 200
    except httpx.HTTPError:
        return False


def ensure_server():
    binary = ollama_binary()
    if not binary:
        raise RuntimeError('Ollama fehlt. Einrichten-Kostenlos starten oder https://ollama.com/download installieren.')
    if not reachable():
        (ROOT/'data').mkdir(exist_ok=True)
        env = os.environ.copy()
        env.update(OLLAMA_HOST='127.0.0.1:11434', OLLAMA_NO_CLOUD='1',
                   OLLAMA_NUM_PARALLEL='1', OLLAMA_KEEP_ALIVE='30m')
        kwargs = {'creationflags':subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS} if os.name == 'nt' else {'start_new_session':True}
        with (ROOT/'data'/'ollama.log').open('ab') as log:
            subprocess.Popen([binary, 'serve'], env=env, stdin=subprocess.DEVNULL,
                             stdout=log, stderr=log, **kwargs)
        for _ in range(60):
            if reachable():
                break
            time.sleep(1)
        else:
            raise RuntimeError('Lokaler Modelldienst startet nicht. data/ollama.log prüfen.')
    return binary


def configure_paths():
    extra = ['/opt/homebrew/bin', '/usr/local/bin']
    if os.name == 'nt':
        local = Path(os.getenv('LOCALAPPDATA',''))
        extra += [str(Path(os.getenv('ProgramFiles','C:/Program Files'))/'Tesseract-OCR'),
                  str(local/'Microsoft'/'WinGet'/'Links')]
        packages = local/'Microsoft'/'WinGet'/'Packages'
        if packages.is_dir():
            extra.extend(str(p) for p in packages.glob('Gyan.FFmpeg_*/ffmpeg-*/bin') if (p/'ffmpeg.exe').is_file())
    os.environ['PATH'] = os.pathsep.join(extra+[os.environ.get('PATH','')])
    missing = [tool for tool in ('ffmpeg','ffprobe','tesseract') if not shutil.which(tool)]
    if missing:
        raise RuntimeError('Fehlende Programme im PATH: '+', '.join(missing)+'. Einrichten-Kostenlos erneut starten.')


def setup(model=None):
    configure_paths()
    info = hardware()
    selected = profile(info)
    if model:
        if model not in MODELS:
            raise ValueError('Nur lokale qwen3-vl-Modelle 2b/4b/8b/32b erlaubt; keine Cloud-Modelle')
        selected['base_model'] = model
    print('Hardware:', json.dumps(info, ensure_ascii=False))
    print('Lokales Startmodell:', selected['base_model'], '· keine API-Gebühren')
    print('Beim ersten Start werden mehrere GB Modelldaten heruntergeladen. Danach ist Offline-Betrieb möglich.')
    binary = ensure_server()
    # Force the CLI onto our loopback service, ignoring unrelated OLLAMA_HOST settings.
    env = {**os.environ, 'OLLAMA_HOST':'127.0.0.1:11434', 'OLLAMA_NO_CLOUD':'1'}
    subprocess.run([binary, 'pull', selected['base_model']], env=env, check=True)
    SETTINGS.parent.mkdir(exist_ok=True)
    modelfile = SETTINGS.parent/'free-model.Modelfile'
    modelfile.write_text(f"FROM {selected['base_model']}\nPARAMETER num_ctx {selected['context_length']}\nPARAMETER temperature 0.1\n", encoding='utf-8')
    subprocess.run([binary, 'create', ALIAS, '-f', str(modelfile)], env=env, check=True)
    verify_model(ALIAS)
    temporary = SETTINGS.with_suffix('.tmp')
    temporary.write_text(json.dumps(selected, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(SETTINGS)
    print('Eingerichtet. Ab jetzt Start-Kostenlos verwenden. Modellwechsel: Einrichten erneut mit --model ausführen.')
    return selected


def verify_model(name):
    with httpx.Client(trust_env=False, timeout=30) as client:
        response = client.post(OLLAMA+'/api/show', json={'model':name})
    if response.status_code != 200 or 'vision' not in response.json().get('capabilities', []):
        raise RuntimeError('Lokales Vision-Modell fehlt oder unterstützt keine Bilder. Einrichtung erneut ausführen.')
    data = response.json()
    if data.get('remote_host') or data.get('remote_model'):
        raise RuntimeError('Remote-Modell im kostenlosen lokalen Modus nicht erlaubt')


def launch(open_browser=True):
    if not SETTINGS.exists():
        raise RuntimeError('Einmal zuerst Einrichten-Kostenlos ausführen.')
    selected = json.loads(SETTINGS.read_text(encoding='utf-8'))
    if selected.get('base_model') not in MODELS or selected.get('model') != ALIAS:
        raise RuntimeError('Ungültige lokale Modelleinstellungen; Einrichtung erneut ausführen.')
    ensure_server()
    verify_model(ALIAS)
    # Explicit local settings: stale cloud keys/URLs cannot trigger paid calls.
    os.environ.pop('APEX_VISION_API_KEY', None)
    os.environ.update(APEX_VISION_MODE='local', APEX_VISION_API_URL=OLLAMA+'/v1/chat/completions',
        APEX_VISION_MODEL=ALIAS, APEX_VISION_FPS=str(selected['fps']),
        APEX_VISION_WINDOW_SECONDS=str(selected['window_seconds']),
        APEX_VISION_OVERLAP_SECONDS=str(selected['overlap_seconds']),
        APEX_VISION_IMAGE_WIDTH=str(selected['image_width']), APEX_VISION_TIMEOUT=str(selected['timeout']),
        APEX_VISION_MAX_WINDOWS='1500', APEX_VISION_MAX_REQUESTS='2000')
    configure_paths()
    os.chdir(ROOT)
    sys.path.insert(0, str(ROOT))
    import uvicorn
    if open_browser:
        import threading
        import webbrowser
        def ready():
            url = 'http://127.0.0.1:'+os.getenv('APEX_PORT','8000')
            for _ in range(60):
                try:
                    with httpx.Client(trust_env=False, timeout=1) as client:
                        if client.get(url+'/api/health').status_code == 200:
                            webbrowser.open(url)
                            return
                except httpx.HTTPError:
                    pass
                time.sleep(1)
        threading.Thread(target=ready, daemon=True).start()
    uvicorn.run('apexcoach.app:app', host='127.0.0.1', port=int(os.getenv('APEX_PORT','8000')), workers=1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Kostenlose lokale Gameplay-Analyse')
    parser.add_argument('--setup', action='store_true')
    parser.add_argument('--model', choices=sorted(MODELS))
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    try:
        setup(args.model) if args.setup else launch(not args.no_browser)
    except (RuntimeError, ValueError, OSError, subprocess.SubprocessError) as exc:
        print('Einrichtung/Start fehlgeschlagen:', exc, file=sys.stderr)
        sys.exit(1)
