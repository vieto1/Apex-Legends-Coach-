const { chromium } = require('playwright');
const { readFile } = require('node:fs/promises');
const assert = require('node:assert/strict');
const base = process.env.APEX_PAGES_URL || 'http://127.0.0.1:8787';
(async () => {
  const source = (await readFile('browser/store.mjs', 'utf8'))
    .replace('../apexcoach/static/resumable-upload.js', new URL('/assets/resumable-upload.js', base).href);
  const browser = await chromium.launch({ executablePath:'/usr/bin/chromium', args:['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    await page.goto(base + '/__import_test__');
    const first = await page.evaluate(async source => {
      const { LocalStore } = await import(URL.createObjectURL(new Blob([source], {type:'text/javascript'})));
      const store = new LocalStore();
      const bytes = new Uint8Array(8*1024**2+37); bytes[bytes.length-1] = 7;
      const file = new File([bytes], 'test.mp4', {type:'video/mp4'});
      const original = store.put.bind(store);
      store.put = (name, value) => {
        if (name === 'chunks' && value.id.endsWith(':1')) throw Error('Synthetic interruption');
        return original(name, value);
      };
      try { await store.saveSource(file, () => {}); } catch (error) {
        if (error.message !== 'Synthetic interruption') throw error;
      }
      const pending = (await store.all('imports'))[0];
      store.db.close();
      return pending;
    }, source);
    assert.equal(first.offset, 8*1024**2);
    await page.reload();
    const second = await page.evaluate(async source => {
      const { LocalStore } = await import(URL.createObjectURL(new Blob([source], {type:'text/javascript'})));
      const store = new LocalStore();
      const bytes = new Uint8Array(8*1024**2+37); bytes[bytes.length-1] = 7;
      const writes = [], original = store.put.bind(store);
      store.put = (name, value) => { if (name === 'chunks') writes.push(value.id); return original(name,value); };
      const pending = await store.saveSource(new File([bytes], 'test.mp4', {type:'video/mp4'}), () => {});
      const saved = await store.get('sources', pending.mid);
      const last = new Uint8Array(await saved.blob.slice(-1).arrayBuffer())[0];
      await store.remove('imports', pending.id);
      await store.deleteMatch(pending.mid);
      return {mid:pending.mid, writes, size:saved.blob.size, last, remaining:(await store.all('chunks')).length};
    }, source);
    assert.equal(second.mid, first.mid);
    assert.deepEqual(second.writes, [`${first.mid}:1`]);
    assert.equal(second.size, 8*1024**2+37);
    assert.equal(second.last, 7);
    assert.equal(second.remaining, 0);
    console.log(JSON.stringify({ localImportResumeAfterReload:true, alreadyCommittedChunkNotRewritten:true, deletionCleansChunks:true }));
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
