#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if [[ "$(uname -s)" == Darwin ]]; then
  command -v brew >/dev/null || { echo 'Zuerst Homebrew von https://brew.sh installieren; dann diese Einrichtung erneut starten.'; exit 1; }
  brew install python@3.12 ffmpeg tesseract ollama
  python_bin="$(brew --prefix python@3.12)/bin/python3.12"
else
  python_bin="$(command -v python3.12 || true)"
  [[ -n "$python_bin" ]] || { echo 'Python 3.12, FFmpeg, Tesseract und Ollama über die offiziellen Systempakete installieren.'; exit 1; }
fi
"$python_bin" -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/free_setup.py --setup "$@"
