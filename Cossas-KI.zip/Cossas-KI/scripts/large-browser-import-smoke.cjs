// Opt-in: APEX_LARGE_VIDEO must point to a real >2-GiB playable video.
// Uses a fresh browser profile; never imports into the user's browser data.
const { chromium } = require('playwright');
const fs = require('node:fs/promises');
const assert = require('node:assert/strict');
const base = process.env.APEX_PAGES_URL || 'http://127.0.0.1:8787';
(async () => {
  const path = process.env.APEX_LARGE_VIDEO;
  assert(path, 'Set APEX_LARGE_VIDEO to a playable file larger than 2 GiB');
  assert((await fs.stat(path)).size > 2 * 1024 ** 3);
  const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    await page.goto(base);
    assert(await page.evaluate(() => document.documentElement.dataset.runtime === 'browser'));
    await page.locator('#file').setInputFiles(path);
    await page.locator('#submit').click();
    await page.waitForFunction(() => document.querySelector('#uploadStatus').textContent.includes('Aufnahme gespeichert'), null, { timeout: 300000 });
    await page.waitForFunction(() => document.querySelector('#analysisStatus').textContent.includes('abgeschlossen'), null, { timeout: 300000 });
    const stored = await page.evaluate(async () => {
      const db = await new Promise((resolve, reject) => {
        const r = indexedDB.open(['apex','review','private'].join('-'), 2);
        r.onsuccess = () => resolve(r.result); r.onerror = () => reject(r.error);
      });
      return new Promise((resolve, reject) => {
        const r = db.transaction('sources').objectStore('sources').getAll();
        r.onsuccess = () => { resolve(r.result.map(x => ({size:x.size, chunks:x.chunk_count}))); db.close(); };
        r.onerror = () => reject(r.error);
      });
    });
    assert(stored.some(x => x.size > 2 * 1024 ** 3 && x.chunks > 256));
    console.log(JSON.stringify({ localImportOverTwoGiB: true, stored, analysis: 'offline HUD only; no cloud quality claim' }));
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
