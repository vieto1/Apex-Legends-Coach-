// Build with APEX_API_BASE_URL=https://backend.example.test first.
// Routes that test origin to the real local FastAPI server; no external requests.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const base = process.env.APEX_PAGES_URL || 'http://127.0.0.1:8787';
const backend = process.env.APEX_BACKEND_TEST_URL || 'http://127.0.0.1:8000';
(async () => {
  const browser = await chromium.launch({ executablePath:'/usr/bin/chromium', args:['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    const errors = [], methods = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.route('https://backend.example.test/**', async route => {
      methods.push(route.request().method());
      const remote = new URL(route.request().url());
      const response = await route.fetch({url: backend + remote.pathname + remote.search});
      await route.fulfill({response});
    });
    await page.goto(base);
    assert.equal(await page.evaluate(() => document.documentElement.dataset.apiBase), 'https://backend.example.test');
    await page.locator('#file').setInputFiles('browser/demo.mp4');
    await page.locator('#submit').click();
    await page.waitForFunction(() => document.querySelector('#analysisStatus').textContent.includes('abgeschlossen'), null, {timeout:90000});
    await page.waitForFunction(() => document.querySelector('#player').readyState >= 2);
    assert(methods.includes('PATCH'));
    assert.equal(await page.locator('#player').evaluate(video => {
      const canvas = document.createElement('canvas'); canvas.width=8; canvas.height=8;
      const ctx = canvas.getContext('2d'); ctx.drawImage(video, 0,0,8,8);
      return ctx.getImageData(0,0,1,1).data.length;
    }), 4); // remote playback must remain usable for HUD calibration (CORS)
    page.once('dialog', d => d.accept());
    await page.locator('#deleteMatch').click();
    await page.waitForFunction(() => document.querySelector('#review').hidden);
    assert.deepEqual(errors, []);
    console.log(JSON.stringify({pagesBackendConnection:true, chunkUpload:true, corsCalibrationCanvas:true, errors}));
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode=1; });
