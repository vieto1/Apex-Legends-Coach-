$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw 'Windows App Installer (winget) fehlt. Über den Microsoft Store installieren und Einrichtung erneut starten.'
}
foreach ($package in @('Python.Python.3.12', 'Gyan.FFmpeg', 'UB-Mannheim.TesseractOCR', 'Ollama.Ollama')) {
    winget install --id $package --exact --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity
    # winget can report an existing current package as a nonzero no-update result.
    if ($LASTEXITCODE -notin @(0, -1978335189)) { throw "Installation fehlgeschlagen: $package (Code $LASTEXITCODE)" }
}
$env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
$python = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'
if (-not (Test-Path $python)) {
    $python = Join-Path $env:ProgramFiles 'Python312\python.exe'
}
if (-not (Test-Path $python)) { throw 'Python 3.12 nicht gefunden. Terminal neu öffnen und Einrichtung erneut starten.' }
& $python -m venv .venv
if ($LASTEXITCODE) { throw 'Python-Umgebung konnte nicht erstellt werden.' }
& .venv\Scripts\python.exe -m pip install -r requirements.txt
if ($LASTEXITCODE) { throw 'Projektabhängigkeiten konnten nicht installiert werden.' }
& .venv\Scripts\python.exe scripts/free_setup.py --setup
if ($LASTEXITCODE) { throw 'Modelleinrichtung fehlgeschlagen; die obige Meldung prüfen.' }
