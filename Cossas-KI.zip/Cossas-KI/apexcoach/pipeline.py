from dataclasses import asdict
from pathlib import Path
import hashlib
import json
import math
import subprocess
import cv2
import numpy as np
from .vision import HudVision, crop, bar_fraction
from .domain import Observation, detect, serialize, summarize
from .coaching import VisionCoach, atomic_json, windows

MAX_SECONDS = 7200


def prepare(source: Path, target: Path):
    # Never silently cut the input. Upload validation explicitly rejects >2 h.
    # Preserve VFR frames and zero the timeline; use measured PTS rather than index/fps below.
    subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-copyts','-start_at_zero','-i',str(source),
                    '-map','0:v:0','-map','0:a:0?',
                    '-vf','pad=ceil(iw/2)*2:ceil(ih/2)*2','-fps_mode','passthrough','-enc_time_base','1:90000',
                    '-c:v','libx264','-preset','veryfast','-crf','24',
                    '-threads','2','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart',str(target)],
                   check=True, timeout=4*3600, capture_output=True)


def analyze(store, mid, profile, perception_factory=HudVision):
    folder = store.root / mid
    cap = None
    coverage = None
    try:
        store.update(mid, status='analyzing', progress=0, phase='Video vorbereiten', summary='{}')
        if not (folder/'video.mp4').exists():
            temp = folder/'preparing.mp4'
            prepare(folder/'source', temp)
            temp.replace(folder/'video.mp4')
        coach = VisionCoach()
        with (folder/'video.mp4').open('rb') as source:
            digest = hashlib.file_digest(source, 'sha256').hexdigest()
        identity = json.dumps([3, digest, profile, coach.fps, coach.image_width, coach.enabled], sort_keys=True)
        identity = hashlib.sha256(identity.encode()).hexdigest()
        checkpoint = folder/'scan.json'
        scan = json.loads(checkpoint.read_text()) if checkpoint.exists() else None
        if scan is None or scan.get('identity') != identity:
            cap = cv2.VideoCapture(str(folder/'video.mp4'))
            fps, expected = cap.get(cv2.CAP_PROP_FPS), int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            if not cap.isOpened() or not math.isfinite(fps) or fps <= 0 or expected <= 0:
                raise ValueError('Video enthält keine lesbaren Frames')
            # Frame presentation timestamps from the actual decoder preserve VFR and
            # B-frame ordering. Metadata is small; video frames are never accumulated.
            pts_file = folder/'frame-times.csv'
            with pts_file.open('wb') as out:
                subprocess.run(['ffprobe','-v','error','-select_streams','v:0',
                    '-show_entries','frame=best_effort_timestamp_time,pkt_duration_time',
                    '-of','csv=p=0',str(folder/'video.mp4')], stdout=out, stderr=subprocess.PIPE,
                    check=True, timeout=4*3600)
            times, frame_duration = [], 1/fps
            for line in pts_file.read_text().splitlines():
                cells = line.split(',')
                if not cells[0].strip():
                    continue
                t = float(cells[0])
                if not math.isfinite(t) or t < 0 or (times and t <= times[-1]):
                    raise ValueError('Videoframe ohne eindeutigen aufsteigenden Zeitstempel')
                times.append(t)
                if len(cells) > 1 and cells[1] not in ('', 'N/A'):
                    value = float(cells[1])
                    if math.isfinite(value) and value > 0:
                        frame_duration = value
            if not times or abs(times[0]) > .1:
                raise ValueError('Videotimeline beginnt nicht bei Null')
            if expected != len(times):
                raise ValueError(f'Frameanzahl und Dekodierung widersprechen sich: {expected}/{len(times)}')
            expected = len(times)
            duration = times[-1]+frame_duration
            if coach.enabled and len(coach.plan(duration)) > coach.max_windows:
                raise ValueError('Vision-Fensterbudget zu klein; APEX_VISION_MAX_WINDOWS erhöhen. Kein gekürztes Video ausgewertet.')
            if duration > MAX_SECONDS+1/fps:
                raise ValueError('Video länger als 2 Stunden; keine gekürzte Analyse erstellt')
            store.update(mid, duration=duration, phase='Alle Videoframes dekodieren / Sequenzen erkennen')
            vision = perception_factory(profile)
            observations, pixel_events, timeline = [], [], []
            previous, last_resources = None, {}
            next_ocr, next_model, decoded = 0., 0., 0
            frames_dir = folder/'vision-frames'
            frames_dir.mkdir(exist_ok=True)
            for path in frames_dir.glob('*.jpg'):
                path.unlink()
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                if decoded >= len(times):
                    raise ValueError('Mehr Videoframes als Zeitstempel; Analyse unvollständig')
                t = times[decoded]
                decoded += 1
                thumb = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (80, 45))
                difference = float(np.mean(cv2.absdiff(thumb, previous))) if previous is not None else 0.
                cut = difference > 65
                previous = thumb
                bucket = min(int(t), math.ceil(duration)-1)
                while bucket >= len(timeline):
                    index = len(timeline)
                    timeline.append({'start': float(index), 'end': min(duration, index+1.),
                                     'frames': 0, 'visual_activity': 0., 'scene_cuts': 0})
                timeline[bucket]['frames'] += 1
                timeline[bucket]['visual_activity'] = max(timeline[bucket]['visual_activity'], round(difference, 3))
                timeline[bucket]['scene_cuts'] += int(cut)
                # Every decoded frame is inspected for calibrated resource changes.
                # OCR remains at 1 Hz, reported separately rather than called full-frame model analysis.
                for key in ('health', 'shield'):
                    roi = profile.get(key+'_roi')
                    value = bar_fraction(crop(frame, roi), key) if roi else None
                    before = last_resources.get(key)
                    if not cut and value is not None and before and abs(value-before[1]) >= .15:
                        loss = value < before[1]
                        pixel_events.append({'kind': 'resource_loss' if loss else 'resource_recovery',
                            'start': before[0], 'end': t,
                            'title': ('Gesundheit' if key == 'health' else 'Schild')+(': möglicher Verlust' if loss else ': mögliche Wiederherstellung'),
                            'advice': 'Ressourcenwechsel im Clip prüfen: Deckung, Heilen oder Schildwechsel abwägen.',
                            'confidence': .5, 'evidence': {'resource': key, 'before_fraction': before[1], 'after_fraction': value,
                                'source': 'every-frame calibrated bar inspection',
                                'limitation': 'Visible HUD pixels, not verified damage or tactical mistake.'}})
                    if cut or value is None:
                        last_resources.pop(key, None)
                    elif before is None or abs(value-before[1]) >= .15:
                        last_resources[key] = (t, value)
                    elif abs(value-before[1]) < .02:
                        last_resources[key] = (t, before[1])
                if t+1e-7 >= next_ocr:
                    observations.append(vision.observe(frame, t))
                    next_ocr = math.floor(t)+1.
                if coach.enabled and t+1e-7 >= next_model:
                    width = min(coach.image_width, frame.shape[1])
                    small = cv2.resize(frame, (width, round(frame.shape[0]*width/frame.shape[1])))
                    if not cv2.imwrite(str(frames_dir/f'{t:012.6f}.jpg'), small, [cv2.IMWRITE_JPEG_QUALITY, 85]):
                        raise OSError('Vision-Frame konnte nicht gespeichert werden')
                    next_model += 1/coach.fps
                if decoded == 1:
                    cv2.imwrite(str(folder/'preview.jpg'), frame)
                if decoded % max(1, round(fps*2)) == 0:
                    store.update(mid, progress=.1+.5*decoded/expected)
            cap.release()
            cap = None
            if decoded != expected:
                raise ValueError(f'Video unvollständig dekodiert: {decoded}/{expected} Frames. Keine vollständige Abdeckung behauptet.')
            if not timeline:
                raise ValueError('Keine Video-Zeitabschnitte dekodiert')
            scan = {'identity': identity, 'duration': duration, 'decoded_frames': decoded, 'expected_frames': expected,
                    'fps': fps, 'timeline': timeline, 'pixel_events': pixel_events,
                    'observations': [asdict(o) for o in observations]}
            atomic_json(checkpoint, scan)
        duration = scan['duration']
        store.update(mid, duration=duration, progress=.6, phase='Sequenzen und Fights zusammenführen')
        observations = [Observation(**o) for o in scan['observations']]
        # Full-frame bar events replace sparse bar events; other existing rules stay intact.
        raw = detect(observations)
        events = [serialize(e) for e in raw if e.kind not in ('resource_loss', 'resource_recovery')]
        events.extend(scan['pixel_events'])
        from .domain import Event, fight_events
        events = [e for e in events if e['kind'] != 'fight']
        events.extend(serialize(e) for e in fight_events([Event(**{k:v for k,v in e.items() if k in Event.__dataclass_fields__}) for e in events]))
        coverage = {'decoded_frames': scan['decoded_frames'], 'expected_frames': scan['expected_frames'],
                    'decode_complete': True, 'start': 0, 'end': duration,
                    'hud_ocr_hz': 1, 'model_frames_per_second': coach.fps if coach.enabled else 0,
                    'model_status': 'running' if coach.enabled else 'not_configured',
                    'model_mode': coach.mode,
                    'model_windows_completed': 0, 'model_windows_total': len(coach.plan(duration))}
        atomic_json(folder/'coverage.json', coverage)
        if coach.enabled:
            store.update(mid, phase=f"{coach.label}: Sequenz 1/{coverage['model_windows_total']}")
            def progress(done, total):
                coverage['model_windows_completed'] = done
                atomic_json(folder/'coverage.json', coverage)
                store.update(mid, phase=f'{coach.label}: Sequenz {done}/{total}', progress=.6+.38*done/total,
                             summary=json.dumps({'coverage':coverage}))
            coaching, plan = coach.run(folder, duration, events, progress, identity)
            events.extend(coaching)
            coverage['model_status'] = 'complete'
            coverage['model_requests_this_run'] = coach.requests
            coverage['model_windows'] = plan
        summary = summarize(observations, raw)
        summary.update(coverage=coverage, fight_count=sum(e['kind']=='fight' for e in events),
                       coaching_count=sum(e['kind']=='coaching' for e in events))
        summary['limitations'].extend(['Alle Frames lokal dekodiert; das Vision-Modell erhält zeitlich abgetastete Bilder, kein Audio.',
            'Vollständige Zeitabdeckung garantiert weder die Erkennung jedes Fights noch korrekte taktische Aussagen.'])
        if not coach.enabled:
            summary['limitations'].append('Vision-Modell nicht aktiviert; ausschließlich lokale HUD-Hinweise, kein taktisches KI-Coaching.')
        atomic_json(folder/'coverage.json', coverage)
        atomic_json(folder/'observations.json', scan['observations'])
        events.sort(key=lambda e: (e['start'], e['kind']))
        with store.connect() as db:
            db.execute("DELETE FROM events WHERE match_id=? AND coalesce(json_extract(payload,'$.origin'),'auto')='auto'", (mid,))
            db.executemany('INSERT INTO events(match_id,payload) VALUES (?,?)', [(mid,json.dumps(e)) for e in events])
        for clip in folder.glob('clip-*.mp4'):
            clip.unlink(missing_ok=True)
        store.update(mid, status='ready', progress=1, phase='Abgeschlossen', error=None, summary=json.dumps(summary))
    except Exception as exc:
        message = f'{type(exc).__name__}: {str(exc)[:300]}'
        if isinstance(exc, subprocess.SubprocessError):
            message = 'Video-Konvertierung fehlgeschlagen oder Zeitbudget überschritten; Original bleibt erhalten.'
        fields = {}
        if coverage is not None:
            coverage['model_status'] = 'failed'
            try:
                atomic_json(folder/'coverage.json', coverage)
            except OSError:
                pass
            fields['summary'] = json.dumps({'coverage': coverage,
                'limitations': ['Analyse unvollständig; fehlende Fenster nach Behebung erneut analysieren.']})
        store.update(mid, status='failed', error=message, phase='Unterbrochen / fehlgeschlagen', **fields)
    finally:
        if cap is not None:
            cap.release()
