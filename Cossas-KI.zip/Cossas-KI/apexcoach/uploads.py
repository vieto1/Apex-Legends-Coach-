"""Durable, offset-based uploads. Only a single chunk is ever held in memory."""
import hashlib
import os
import shutil
import threading
from uuid import uuid4
from fastapi import HTTPException, Request
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

CHUNK_BYTES = 8 * 1024**2


class UploadSpec(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    size: int = Field(gt=0, le=2**53-1)
    fingerprint: str = Field(pattern=r'^[a-f0-9]{64}$')
    profile: dict = Field(default_factory=dict)


class Uploads:
    def __init__(self, store):
        self.store = store
        self.root = store.root / 'uploads'
        self.root.mkdir(exist_ok=True)
        self.lock = threading.RLock()
        with store.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS uploads (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, size INTEGER NOT NULL,
                fingerprint TEXT NOT NULL, profile TEXT NOT NULL, offset INTEGER NOT NULL DEFAULT 0,
                match_id TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP)''')

    def get(self, uid):
        with self.store.connect() as db:
            row = db.execute('SELECT * FROM uploads WHERE id=?', (uid,)).fetchone()
        if row is None:
            raise HTTPException(404, 'Upload nicht gefunden oder gelöscht')
        return dict(row)

    def status(self, uid):
        with self.lock:
            row = self.get(uid)
            path = self.root / uid
            if not row['match_id']:
                # A crash after fsync but before SQLite commit can leave extra bytes.
                # Only the committed offset is acknowledged; uncommitted bytes are retried.
                with path.open('r+b') as out:
                    if out.seek(0, 2) < row['offset']:
                        raise HTTPException(409, 'Upload-Datei beschädigt; Upload löschen und neu beginnen')
                    out.truncate(row['offset'])
            return {k: row[k] for k in ('id', 'size', 'offset', 'match_id')} | {'chunk_bytes': CHUNK_BYTES}

    def create(self, spec, profile):
        import json
        with self.lock:
            with self.store.connect() as db:
                existing = db.execute('SELECT id FROM uploads WHERE fingerprint=? AND profile=?',
                                      (spec.fingerprint, json.dumps(profile, sort_keys=True))).fetchone()
            if existing:
                return self.status(existing['id'])
            if shutil.disk_usage(self.root).free < spec.size + 64*1024**2:
                raise HTTPException(507, 'Nicht genug freier Speicher für die Originaldatei')
            uid = uuid4().hex
            (self.root/uid).touch(exist_ok=False)
            with self.store.connect() as db:
                db.execute('INSERT INTO uploads(id,name,size,fingerprint,profile) VALUES (?,?,?,?,?)',
                           (uid, spec.name, spec.size, spec.fingerprint, json.dumps(profile, sort_keys=True)))
            return self.status(uid)

    def append(self, uid, offset, data, checksum):
        with self.lock:
            row = self.status(uid)
            if row['match_id'] or row['offset'] != offset:
                raise HTTPException(409, 'Upload-Offset geändert; Status erneut laden')
            if not data or len(data) > CHUNK_BYTES or offset + len(data) > row['size']:
                raise HTTPException(413, 'Ungültige Blockgröße')
            if hashlib.sha256(data).hexdigest() != checksum:
                raise HTTPException(422, 'Block-Prüfsumme stimmt nicht überein')
            try:
                with (self.root/uid).open('r+b') as out:
                    out.seek(offset)
                    out.write(data)
                    out.flush()
                    os.fsync(out.fileno())
                with self.store.connect() as db:
                    db.execute('UPDATE uploads SET offset=? WHERE id=?', (offset+len(data), uid))
            except OSError as exc:
                raise HTTPException(507, 'Upload-Speicher nicht beschreibbar; nach Freigabe fortsetzen') from exc
            return self.status(uid)

    def delete(self, uid):
        with self.lock:
            self.get(uid)
            (self.root/uid).unlink(missing_ok=True)
            with self.store.connect() as db:
                db.execute('DELETE FROM uploads WHERE id=?', (uid,))


def register_uploads(app, store, profile_type, submit):
    import json
    uploads = Uploads(store)
    app.state.uploads = uploads

    @app.post('/api/uploads', status_code=201)
    def create_upload(spec: UploadSpec):
        try:
            profile = profile_type.model_validate(spec.profile).model_dump()
        except ValueError as exc:
            raise HTTPException(422, 'Ungültiges HUD-Profil') from exc
        return uploads.create(spec, profile)

    @app.get('/api/uploads/{uid}')
    def upload_status(uid: str):
        return uploads.status(uid)

    @app.patch('/api/uploads/{uid}')
    async def upload_chunk(uid: str, request: Request):
        try:
            offset = int(request.headers.get('upload-offset', '-1'))
        except ValueError as exc:
            raise HTTPException(400, 'Ungültiger Upload-Offset') from exc
        checksum = request.headers.get('upload-checksum', '')
        if offset < 0 or len(checksum) != 64:
            raise HTTPException(400, 'Upload-Offset und SHA-256 erforderlich')
        data = bytearray()
        async for block in request.stream():
            if len(data)+len(block) > CHUNK_BYTES:
                raise HTTPException(413, 'Upload-Block darf höchstens 8 MiB enthalten')
            data.extend(block)
        return await run_in_threadpool(uploads.append, uid, offset, data, checksum)

    @app.post('/api/uploads/{uid}/complete', status_code=202)
    def complete_upload(uid: str):
        with uploads.lock:
            row = uploads.get(uid)
            if row['match_id']:
                return {'id': row['match_id']}
            if uploads.status(uid)['offset'] != row['size']:
                raise HTTPException(409, 'Upload ist noch nicht vollständig')
            result = submit(uploads.root/uid, row['name'], json.loads(row['profile']), uid)
            # submit uses uid as match id. A crash between queueing and this commit
            # is recovered by the matches lookup in submit, without a duplicate job.
            with store.connect() as db:
                db.execute('UPDATE uploads SET match_id=? WHERE id=?', (result['id'], uid))
            (uploads.root/uid).unlink(missing_ok=True)
            return result

    @app.delete('/api/uploads/{uid}', status_code=204)
    def delete_upload(uid: str):
        uploads.delete(uid)
