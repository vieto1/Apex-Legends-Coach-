// Bounded memory: hash/read at most one 8-MiB block, never the whole video.
export const CHUNK_BYTES = 8 * 1024 ** 2;
const hex = (bytes) => [...new Uint8Array(bytes)].map(x => x.toString(16).padStart(2, "0")).join("");
export async function identify(file, progress = () => {}) {
  const hashes = [];
  for (let offset = 0; offset < file.size; offset += CHUNK_BYTES) {
    hashes.push(await crypto.subtle.digest("SHA-256", await file.slice(offset, offset + CHUNK_BYTES).arrayBuffer()));
    progress(Math.min(1, (offset + CHUNK_BYTES) / file.size), "Datei prüfen");
  }
  const manifest = new Blob([String(file.size), "\n", ...hashes]);
  return { fingerprint: hex(await crypto.subtle.digest("SHA-256", await manifest.arrayBuffer())), hashes: hashes.map(hex) };
}

export async function uploadRemote(file, profile, request, progress = () => {}) {
  const { fingerprint } = await identify(file, progress);
  let session = await request("/api/uploads", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: file.name || "Gameplay", size: file.size, fingerprint, profile }),
  });
  let failures = 0;
  let chunkBytes = Math.min(CHUNK_BYTES, session.chunk_bytes, 1024 ** 2);
  while (!session.match_id && session.offset < file.size) {
    try {
      const chunk = file.slice(session.offset, session.offset + chunkBytes);
      session = await request(`/api/uploads/${session.id}`, {
        method: "PATCH", headers: { "Content-Type": "application/octet-stream",
          "Upload-Offset": String(session.offset),
          "Upload-Checksum": hex(await crypto.subtle.digest("SHA-256", await chunk.arrayBuffer())) }, body: chunk,
      });
      failures = 0;
      progress(session.offset / file.size, "Upload");
    } catch (e) {
      if (e.status && ![408, 409, 429, 500, 502, 503, 504].includes(e.status)) throw e;
      chunkBytes = Math.max(64 * 1024, Math.floor(chunkBytes / 2));
      if (++failures > 6) throw Error("Upload unterbrochen. Dieselbe Datei erneut auswählen und starten; gespeicherte Blöcke werden fortgesetzt.");
      progress(session.offset / file.size, "Verbindung unterbrochen · Wiederverbindung");
      await new Promise(r => setTimeout(r, Math.min(1000 * 2 ** (failures - 1), 15000)));
      // A lost acknowledgement is resolved using the durable server offset.
      try { session = await request(`/api/uploads/${session.id}`); } catch {}
    }
  }
  progress(1, "Upload abgeschlossen · Video prüfen");
  // Completion is idempotent, including after a lost response or page reload.
  return request(`/api/uploads/${session.id}/complete`, { method: "POST" });
}
