import hashlib
import os
import struct
import subprocess
import time
import pytest
from fastapi.testclient import TestClient
from apexcoach.app import create_app
from apexcoach.uploads import CHUNK_BYTES


def metadata(data, name='game.mp4'):
    return {'name': name, 'size': len(data), 'fingerprint': hashlib.sha256(data).hexdigest(), 'profile': {}}


def send(client, uid, data, offset=0, checksum=None):
    return client.patch(f'/api/uploads/{uid}', content=data, headers={
        'Upload-Offset': str(offset), 'Upload-Checksum': checksum or hashlib.sha256(data).hexdigest(),
        'Content-Type': 'application/octet-stream'})


def video(path, seconds=2):
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',f'color=c=black:s=160x90:r=2:d={seconds}',
                    '-c:v','libx264','-preset','ultrafast','-threads','2','-pix_fmt','yuv420p',str(path)], check=True)


def test_resume_restart_checksum_offsets_and_completion(tmp_path):
    path = tmp_path/'game.mp4'
    video(path)
    data = path.read_bytes()
    root = tmp_path/'data'
    spec = metadata(data)
    with TestClient(create_app(root)) as client:
        uid = client.post('/api/uploads', json=spec).json()['id']
        assert send(client, uid, data[:100], checksum='0'*64).status_code == 422
        assert send(client, uid, data[:100]).json()['offset'] == 100
        assert send(client, uid, data[:100]).status_code == 409  # lost acknowledgement
        assert client.post(f'/api/uploads/{uid}/complete').status_code == 409
    # Unacknowledged bytes from a crash are discarded, not counted twice.
    with (root/'uploads'/uid).open('ab') as out:
        out.write(b'uncommitted')
    with TestClient(create_app(root)) as client:
        session = client.post('/api/uploads', json=spec).json()
        assert session['id'] == uid and session['offset'] == 100
        assert (root/'uploads'/uid).stat().st_size == 100
        assert send(client, uid, data[100:], 100).json()['offset'] == len(data)
        response = client.post(f'/api/uploads/{uid}/complete')
        assert response.status_code == 202, response.text
        mid = response.json()['id']
        assert client.post(f'/api/uploads/{uid}/complete').json()['id'] == mid
        assert (root/mid/'source').read_bytes() == data
    with TestClient(create_app(root)) as client:
        assert client.get(f'/api/uploads/{uid}').json()['match_id'] == mid
        assert client.post(f'/api/uploads/{uid}/complete').json()['id'] == mid
        assert client.delete(f'/api/matches/{mid}').status_code == 204
        assert client.get(f'/api/uploads/{uid}').status_code == 404


def test_chunk_limits_deletion_and_invalid_video(tmp_path):
    with TestClient(create_app(tmp_path/'data')) as client:
        uid = client.post('/api/uploads', json=metadata(b'x')).json()['id']
        assert send(client, uid, b'xx').status_code == 413
        assert send(client, uid, b'x').status_code == 200
        assert client.post(f'/api/uploads/{uid}/complete').status_code == 422
        assert client.get(f'/api/uploads/{uid}').json()['offset'] == 1
        assert client.delete(f'/api/uploads/{uid}').status_code == 204
        assert client.get(f'/api/uploads/{uid}').status_code == 404
        assert client.post('/api/uploads', json=metadata(b'')).status_code == 422


def test_pages_cors_is_explicit_and_blocks_other_origins(tmp_path, monkeypatch):
    monkeypatch.setenv('APEX_ALLOWED_ORIGINS', 'https://vieto1.github.io')
    with TestClient(create_app(tmp_path/'data')) as client:
        headers = {'Origin': 'https://vieto1.github.io'}
        response = client.post('/api/uploads', json=metadata(b'x'), headers=headers)
        assert response.status_code == 201
        assert response.headers['access-control-allow-origin'] == headers['Origin']
        assert response.headers['access-control-allow-credentials'] == 'true'
        preflight = client.options('/api/uploads/test', headers={**headers,
            'Access-Control-Request-Method':'PATCH',
            'Access-Control-Request-Headers':'Upload-Offset,Upload-Checksum,Content-Type'})
        assert preflight.status_code == 200
        assert client.post('/api/uploads', json=metadata(b'y'),
            headers={'Origin':'https://untrusted.example'}).status_code == 403


@pytest.mark.skipif(os.getenv('APEX_RUN_LARGE_UPLOAD_TEST') != '1', reason='opt-in: writes >2 GiB to disk')
def test_actual_upload_over_two_gib_and_full_decode(tmp_path):
    path = tmp_path/'large.mp4'
    video(path)
    # Valid MP4 free box: legal padding, not fake metadata or a mocked length.
    # Source is sparse; HTTP still transfers and checksums every byte.
    with path.open('ab') as out:
        box_size = 2*1024**3 + 1024
        out.write(struct.pack('>I4sQ', 1, b'free', box_size))
        out.truncate(path.stat().st_size + box_size - 16)
    size = path.stat().st_size
    assert size > 2*1024**3
    with path.open('rb') as source:
        expected_hash = hashlib.file_digest(source, 'sha256').hexdigest()
    root = tmp_path/'data'
    with TestClient(create_app(root)) as client:
        spec = {'name': path.name, 'size': size, 'fingerprint': expected_hash, 'profile': {}}
        session = client.post('/api/uploads', json=spec).json()
        uid = session['id']
        offset = 0
        with path.open('rb') as source:
            while block := source.read(CHUNK_BYTES):
                response = send(client, uid, block, offset)
                assert response.status_code == 200, response.text
                offset = response.json()['offset']
        assert offset == size
        response = client.post(f'/api/uploads/{uid}/complete')
        assert response.status_code == 202, response.text
        mid = response.json()['id']
        for _ in range(300):
            result = client.get(f'/api/matches/{mid}').json()
            if result['status'] in ('ready','failed'):
                break
            time.sleep(.1)
        assert result['status'] == 'ready', result
        assert result['summary']['coverage']['decode_complete']
        with (root/mid/'source').open('rb') as source:
            assert hashlib.file_digest(source, 'sha256').hexdigest() == expected_hash
