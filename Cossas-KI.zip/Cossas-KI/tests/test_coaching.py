import json
import math
import httpx
import pytest
from apexcoach.coaching import VisionCoach, windows, validate_result, ContextBudgetError
from apexcoach.pipeline import analyze
from apexcoach.store import Store
from tests.test_uploads import video


@pytest.mark.parametrize('duration', [.1, 16, 20, 32, 45.25, 1500, 7200])
def test_windows_cover_every_second_and_own_boundaries_once(duration):
    plan = list(windows(duration))
    assert plan[0]['start'] == 0 and plan[-1]['end'] == duration
    assert plan[-1]['owned_end'] == duration
    for left, right in zip(plan, plan[1:]):
        assert left['owned_end'] == right['start']
        assert left['end'] - right['start'] == 4


def answer(start=0, end=1):
    return {'events': [{'start': start, 'end': end, 'what_happened': 'Synthetische Testszene',
        'mistake_or_opportunity': 'Testchance', 'better_decision': 'Testempfehlung',
        'confidence': .7, 'evidence_seconds': [0]}]}


def test_model_receives_real_images_and_rejects_unseen_evidence(tmp_path, monkeypatch):
    monkeypatch.setenv('APEX_VISION_MODE', 'cloud')
    monkeypatch.setenv('APEX_VISION_API_KEY', 'synthetic-test-key')
    frame = tmp_path/'0.jpg'
    video_path = tmp_path/'video.mp4'
    video(video_path)
    import cv2
    cap = cv2.VideoCapture(str(video_path))
    ok, image = cap.read()
    cap.release()
    assert ok and cv2.imwrite(str(frame), image)
    def handle(request):
        body = json.loads(request.content)
        content = body['messages'][0]['content']
        assert any(p.get('image_url', {}).get('url', '').startswith('data:image/jpeg;base64,/9j/') for p in content)
        return httpx.Response(200, json={'choices':[{'finish_reason':'stop', 'message':{'content':json.dumps(answer())}}]})
    original = httpx.Client
    monkeypatch.setattr(httpx, 'Client', lambda **kwargs: original(transport=httpx.MockTransport(handle), **kwargs))
    result = VisionCoach().review({'start':16, 'end':20}, [(16, frame)], [])
    assert result['events'][0]['what_happened'] == 'Synthetische Testszene'
    invalid = answer()
    invalid['events'][0]['evidence_seconds'] = [1.234]
    with pytest.raises(ValueError, match='nicht übergebene'):
        validate_result(invalid, {'start':0, 'end':4}, [0])
    with pytest.raises(ValueError, match='außerhalb'):
        validate_result(answer(0, 9), {'start':0, 'end':4}, [0])


def test_25_minutes_decode_all_frames_model_windows_resume_and_timestamps(tmp_path, monkeypatch):
    monkeypatch.setenv('APEX_VISION_MODE', 'cloud')
    monkeypatch.setenv('APEX_VISION_API_KEY', 'synthetic-test-key')
    store = Store(tmp_path/'data')
    mid = 'long-video'
    folder = store.root/mid
    folder.mkdir()
    video(folder/'video.mp4', 1500)
    with store.connect() as db:
        db.execute("INSERT INTO matches(id,name,status,profile) VALUES (?,?,?,?)", (mid, 'test', 'queued', '{}'))
    calls = []
    fail = [True]
    def review(self, window, frames, signals):
        assert frames and all(path.stat().st_size > 0 for _, path in frames)
        calls.append(window['start'])
        if window['start'] >= 32 and fail[0]:
            raise RuntimeError('Synthetic network interruption')
        return answer(0, min(1, window['end']-window['start']))
    monkeypatch.setattr(VisionCoach, 'review', review)
    analyze(store, mid, {})
    assert store.match(mid)['status'] == 'failed'
    assert store.match(mid)['summary']['coverage']['model_status'] == 'failed'
    assert store.match(mid)['summary']['coverage']['model_windows_completed'] == 2
    assert json.loads((folder/'coverage.json').read_text())['model_windows_completed'] == 2
    fail[0] = False
    analyze(store, mid, {})
    result = store.match(mid)
    assert result['status'] == 'ready', result
    coverage = result['summary']['coverage']
    assert coverage['decoded_frames'] == 3000 and coverage['decode_complete']
    assert coverage['end'] == 1500
    assert coverage['model_windows_completed'] == coverage['model_windows_total']
    assert coverage['model_status'] == 'complete'
    assert calls.count(0) == 1 and calls.count(16) == 1  # checkpoint reuse, no double billing
    findings = [e for e in result['events'] if e['kind']=='coaching']
    assert findings[0]['start'] == 0
    assert findings[-1]['start'] == list(windows(1500))[-1]['start']
    assert all(0 <= e['start'] <= e['end'] <= 1500 for e in findings)
    timeline = json.loads((folder/'scan.json').read_text())['timeline']
    assert len(timeline) == 1500 and all(bucket['frames'] == 2 for bucket in timeline)


def test_window_budget_fails_instead_of_skipping(tmp_path, monkeypatch):
    monkeypatch.setenv('APEX_VISION_MAX_WINDOWS','1')
    with pytest.raises(ValueError, match='Keine Fenster übersprungen'):
        VisionCoach().run(tmp_path, 50, [], lambda *args: None, 'identity')


def test_context_limit_splits_without_losing_windows_and_reuses_children(tmp_path, monkeypatch):
    coach = VisionCoach()
    frames = []
    for index in range(40):
        path = tmp_path/f'{index}.jpg'
        path.write_bytes(b'synthetic frame; review is mocked')
        frames.append((index/2, path))
    calls = []
    def review(window, selected, signals):
        calls.append((window['start'], window['end']))
        if window['end']-window['start'] > 12:
            raise ContextBudgetError()
        return {'events': [], 'fights': []}
    monkeypatch.setattr(coach, 'review', review)
    window = {'start':0, 'end':20}
    assert coach.bounded_review(window, frames, [], tmp_path)['events'] == []
    assert calls == [(0,20), (0,10.5), (9.5,20)]
    # Both children cover the whole original interval, with boundary context.
    count = len(calls)
    coach.bounded_review(window, frames, [], tmp_path)
    assert len(calls) == count


def test_variable_frame_rate_preserves_all_frames_and_measured_timestamps(tmp_path):
    import subprocess
    from apexcoach.pipeline import prepare
    source, target = tmp_path/'variable.mkv', tmp_path/'normalized.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=s=160x90:r=10:d=3',
        '-vf', 'setpts=if(lt(N\\,10)\\,N/(10*TB)\\,(1+(N-10)/5)/TB)',
        '-fps_mode','vfr','-c:v','ffv1','-threads','2',str(source)], check=True)
    def timestamps(path):
        p = subprocess.run(['ffprobe','-v','error','-select_streams','v:0',
            '-show_entries','frame=best_effort_timestamp_time','-of','json',str(path)], capture_output=True, check=True)
        return [float(x['best_effort_timestamp_time']) for x in json.loads(p.stdout)['frames']]
    original = timestamps(source)
    prepare(source, target)
    normalized = timestamps(target)
    assert len(original) == len(normalized) == 30
    assert max(abs(a-b) for a,b in zip(original, normalized)) < .001
    assert abs((normalized[-1]-normalized[-2]) - .2) < .001
