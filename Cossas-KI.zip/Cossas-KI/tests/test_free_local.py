import json
import httpx
import pytest
from fastapi.testclient import TestClient
from apexcoach.app import create_app
from apexcoach.coaching import VisionCoach
from scripts import free_setup
from apexcoach.pipeline import analyze
from apexcoach.store import Store
from tests.test_uploads import video


@pytest.mark.parametrize('apple,ram,vram,model', [
    (True, 8, 0, 'qwen3-vl:2b'), (True,16,0,'qwen3-vl:4b'),
    (True,24,0,'qwen3-vl:8b'), (True,64,0,'qwen3-vl:32b'),
    (False,32,8,'qwen3-vl:4b'), (False,32,16,'qwen3-vl:8b'),
    (False,128,0,'qwen3-vl:2b'), (False,0,0,'qwen3-vl:2b')])
def test_conservative_hardware_profiles(apple, ram, vram, model):
    info = {'system':'Darwin' if apple else 'Windows', 'apple_silicon':apple,
            'ram_gib':ram, 'gpu_vram_gib':vram}
    value = free_setup.profile(info)
    assert value['base_model'] == model
    assert value['context_length'] in (8192,16384)
    assert value['model'] == 'cossas-ki-free'


def test_cloud_key_alone_never_enables_paid_requests(monkeypatch):
    monkeypatch.delenv('APEX_VISION_MODE', raising=False)
    monkeypatch.setenv('APEX_VISION_API_KEY', 'synthetic-unused-key')
    coach = VisionCoach()
    assert not coach.enabled and coach.key == ''
    with pytest.raises(ValueError, match='nicht aktiviert'):
        coach.review({'start':0,'end':1}, [], [])


def test_local_mode_rejects_cloud_endpoint(monkeypatch):
    monkeypatch.setenv('APEX_VISION_MODE','local')
    monkeypatch.setenv('APEX_VISION_API_URL','https://api.openai.com/v1/chat/completions')
    with pytest.raises(ValueError, match='kein Cloud-Endpunkt'):
        VisionCoach()


def test_local_vision_without_key_sends_images_but_no_credentials(tmp_path, monkeypatch):
    monkeypatch.setenv('APEX_VISION_MODE','local')
    monkeypatch.delenv('APEX_VISION_API_URL', raising=False)
    monkeypatch.setenv('APEX_VISION_API_KEY','synthetic-key-that-must-not-be-sent')
    frame = tmp_path/'frame.jpg'
    import cv2
    import numpy as np
    cv2.imwrite(str(frame), np.zeros((90,160,3), dtype=np.uint8))
    original = httpx.Client
    def handle(request):
        assert request.url.host == '127.0.0.1' and request.url.port == 11434
        assert 'authorization' not in request.headers
        content = json.loads(request.content)['messages'][0]['content']
        assert any(part.get('image_url',{}).get('url','').startswith('data:image/jpeg;base64,') for part in content)
        return httpx.Response(200, json={'choices':[{'finish_reason':'stop',
            'message':{'content':json.dumps({'events':[], 'fights':[]})}}]})
    def client(**kwargs):
        assert kwargs['trust_env'] is False
        assert kwargs['timeout'].read == 1200
        return original(transport=httpx.MockTransport(handle), **kwargs)
    monkeypatch.setattr(httpx, 'Client', client)
    coach = VisionCoach()
    assert coach.enabled and coach.key == ''
    assert coach.review({'start':0,'end':1}, [(0,frame)], []) == {'events':[], 'fights':[]}


def test_local_health_reports_local_not_cloud(tmp_path, monkeypatch):
    monkeypatch.setenv('APEX_VISION_MODE','local')
    monkeypatch.delenv('APEX_VISION_API_URL', raising=False)
    with TestClient(create_app(tmp_path/'data')) as client:
        health = client.get('/api/health').json()
        assert health['vision_mode'] == 'local' and health['vision_model_configured']
        assert health['vision_model'] == 'qwen3-vl:4b'


def test_setup_uses_only_local_models_and_persists_no_secrets(tmp_path, monkeypatch):
    monkeypatch.setattr(free_setup, 'ROOT', tmp_path)
    monkeypatch.setattr(free_setup, 'SETTINGS', tmp_path/'data'/'free-settings.json')
    monkeypatch.setattr(free_setup, 'hardware', lambda: {'system':'Darwin','apple_silicon':True,'ram_gib':16,'gpu_vram_gib':0})
    monkeypatch.setattr(free_setup, 'ensure_server', lambda:'ollama')
    monkeypatch.setattr(free_setup, 'verify_model', lambda name: None)
    calls = []
    monkeypatch.setattr(free_setup.subprocess, 'run', lambda args, **kwargs: calls.append((args,kwargs)))
    with pytest.raises(ValueError):
        free_setup.setup('paid-cloud-model')
    selected = free_setup.setup()
    assert selected['base_model'] == 'qwen3-vl:4b'
    assert calls[0][0] == ['ollama','pull','qwen3-vl:4b']
    assert all(kwargs['env']['OLLAMA_HOST'] == '127.0.0.1:11434' for _,kwargs in calls)
    text = free_setup.SETTINGS.read_text()
    assert 'API_KEY' not in text and 'api.openai.com' not in text
    assert 'PARAMETER num_ctx 16384' in (tmp_path/'data'/'free-model.Modelfile').read_text()


def test_remote_ollama_model_is_rejected(monkeypatch):
    original = httpx.Client
    def handle(request):
        return httpx.Response(200, json={'capabilities':['vision'], 'remote_host':'cloud.example'})
    monkeypatch.setattr(httpx, 'Client', lambda **kwargs:original(transport=httpx.MockTransport(handle), **kwargs))
    with pytest.raises(RuntimeError, match='Remote-Modell'):
        free_setup.verify_model('cossas-ki-free')


def test_full_local_pipeline_without_any_api_key(tmp_path, monkeypatch):
    monkeypatch.setenv('APEX_VISION_MODE','local')
    monkeypatch.delenv('APEX_VISION_API_URL', raising=False)
    monkeypatch.delenv('APEX_VISION_API_KEY', raising=False)
    original = httpx.Client
    requests = []
    def handle(request):
        assert request.url.host == '127.0.0.1'
        assert 'authorization' not in request.headers
        content = json.loads(request.content)['messages'][0]['content']
        assert any('image_url' in part for part in content)
        requests.append(request.url)
        result = {'events':[{'start':1, 'end':2, 'what_happened':'Synthetische Szene',
            'mistake_or_opportunity':'Synthetische Chance', 'better_decision':'Synthetischer Testhinweis',
            'confidence':.5, 'evidence_seconds':[1]}], 'fights':[]}
        return httpx.Response(200, json={'choices':[{'finish_reason':'stop', 'message':{'content':json.dumps(result)}}]})
    monkeypatch.setattr(httpx,'Client',lambda **kwargs:original(transport=httpx.MockTransport(handle),**kwargs))
    store = Store(tmp_path/'data')
    folder = store.root/'local-test'
    folder.mkdir()
    video(folder/'video.mp4', 30)
    with store.connect() as db:
        db.execute("INSERT INTO matches(id,name,status,profile) VALUES ('local-test','test','queued','{}')")
    analyze(store,'local-test',{})
    result = store.match('local-test')
    assert result['status'] == 'ready', result
    coverage = result['summary']['coverage']
    assert coverage['model_mode'] == 'local' and coverage['model_status'] == 'complete'
    assert coverage['decoded_frames'] == 60
    assert coverage['model_windows_completed'] == coverage['model_windows_total'] == len(requests) == 5
    assert [e['start'] for e in result['events'] if e['kind']=='coaching'] == [1,7,13,19,25]
    assert all(e['evidence']['source']=='local vision model' for e in result['events'])


def test_free_launcher_overrides_stale_cloud_configuration(tmp_path, monkeypatch):
    monkeypatch.setattr(free_setup,'ROOT',tmp_path)
    monkeypatch.setattr(free_setup,'SETTINGS',tmp_path/'free-settings.json')
    settings = free_setup.profile({'system':'Darwin','apple_silicon':True,'ram_gib':16,'gpu_vram_gib':0})
    free_setup.SETTINGS.write_text(json.dumps(settings))
    monkeypatch.setattr(free_setup,'ensure_server', lambda: 'ollama')
    monkeypatch.setattr(free_setup,'verify_model', lambda name: None)
    monkeypatch.setattr(free_setup.shutil,'which',lambda name:'/fake/'+name)
    monkeypatch.setenv('APEX_VISION_API_KEY','synthetic-stale-key')
    monkeypatch.setenv('APEX_VISION_API_URL','https://api.openai.com/v1/chat/completions')
    import uvicorn
    def run(*args,**kwargs):
        coach = VisionCoach()
        assert coach.mode=='local' and coach.enabled and coach.key==''
        assert coach.url=='http://127.0.0.1:11434/v1/chat/completions'
        assert kwargs['host']=='127.0.0.1' and kwargs['workers']==1
    monkeypatch.setattr(uvicorn,'run',run)
    # launch mutates only its process environment, so isolate those mutations in this test.
    monkeypatch.setattr(free_setup.os,'environ',dict(free_setup.os.environ))
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(free_setup.sys,'path',list(free_setup.sys.path))
    free_setup.launch(open_browser=False)
