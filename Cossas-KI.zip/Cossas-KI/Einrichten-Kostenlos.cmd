@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0scripts\setup-free.ps1"
if errorlevel 1 (
 echo Einrichtung fehlgeschlagen. Meldung oben und docs\free-local.md beachten.
 pause
 exit /b 1
)
echo Einrichtung abgeschlossen. Ab jetzt Start-Kostenlos.cmd verwenden.
pause
